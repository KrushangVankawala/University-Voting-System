<?php
session_start();
session_destroy();
//$_SESSION['username']="";
//$_SESSION['loginstatus']="";

header("location:index.php");


/*$_SESSION["id"]="";
		$_SESSION['loginstatus']="";
		header("location:index.php");
*/
		?>