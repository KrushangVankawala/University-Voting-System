<div class="left-sidebar bg-black-300 box-shadow ">
                        <div class="sidebar-content">
                            <div class="user-info">
							
                                <img src="images/user.jpg" alt="YRS" class="img-circle profile-img" height="85" width="85">
                                <h5 class="title">ADMIN</h5>
                                
                            </div>
                            <!-- /.user-info -->

                            <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li class="nav-header">
                                        <span class="">Main Category</span>
                                    </li>
                                    <li>
                                        <a href="dashboard.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span> </a>
                                     
                                    </li>

                                    <li class="nav-header">
                                        <span class="">Appearance</span>
                                    </li>
 <li class="has-children">
                                        <a href="#"><i class="fa fa-file-text"></i> <span>Voter</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="voter_list.php"><i class="fa fa-bars"></i> <span>List Of Voter</span></a></li>
                                          
                                        </ul>
    </li>
<li class="has-children">
                                        <a href="#"><i class="fa fa-file-text"></i> <span>Candidate</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="add_candidate.php"><i class="fa fa-bars"></i> <span>Add Candidate</span></a></li>
                                            <li><a href="manage_candidate.php"><i class="fa fa-bars"></i> <span>Manage Candidate</span></a></li>
                                        </ul>
    </li>
	<li class="has-children">
                                        <a href="#"><i class="fa fa-file-text"></i> <span>Committy</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="committy_list.php"><i class="fa fa-bars"></i> <span>List Of Committy</span></a></li>
											<li><a href="add_committy.php"><i class="fa fa-bars"></i> <span>Add Committy</span></a></li>
                                        </ul>
    </li>
   
	<li class="has-children">
										<li><a href="election.php"><i class="fa  fa-server"></i> <span>Election</span> </i></a></li>
                                        
    </li>
	<li class="has-children">
                                        <a href="#"><i class="fa fa-file-text"></i> <span>Result</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="voter/1.php"><i class="fa fa-bars"></i> <span>Post Wise Result</span></a></li>
											<li><a href="voter/2.php"><i class="fa fa-bars"></i> <span>Percentage of Voting</span></a></li>
											<li><a href="voter/3.php"><i class="fa fa-bars"></i> <span>Gender Wise Result</span></a></li>
											<li><a href="voter/4.php"><i class="fa fa-bars"></i> <span>Institute Wise Result</span></a></li>
                                        </ul>
    </li>
	<li class="has-children">
                                        <li><a href="admin_password_change.php"><i class="fa fa fa-server"></i> <span> Admin Change Password</span></a></li>
    </li>
                            </div>
                            <!-- /.sidebar-nav -->
                        </div>
                        <!-- /.sidebar-content -->
                    </div>